﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Personal_Data_Vault
{
    /// <summary>
    /// Interaction logic for RecoverDeletedFiles.xaml
    /// </summary>
    public partial class RecoverDeletedFiles : Window
    {
        public static List<int> filesToRecover;

        public RecoverDeletedFiles()
        {
            InitializeComponent();

            RecoveryOptions.ItemsSource = Block.recoveryFilesList;
            RecoveryOptions.InvalidateArrange();
            RecoveryOptions.Items.Refresh();
            RecoveryOptions.UpdateLayout();

            filesToRecover = new List<int>();
        }

        /* If the checkbox is checked, get ready to recover it. */
        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            RecoveryFilesInfo info = checkBox.DataContext as RecoveryFilesInfo;
            int index = info.recoveryFileIndex;

            filesToRecover.Add(index);
        }

        /* If the checkbox is unchecked, don't recover it. */
        private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            RecoveryFilesInfo info = checkBox.DataContext as RecoveryFilesInfo;
            int index = info.recoveryFileIndex;

            for(int i = 0; i < filesToRecover.Count; i++)
            {
                if(filesToRecover[i] == index)
                {
                    filesToRecover.RemoveAt(i);
                }
            }
        }

        private void Submit(object sender, RoutedEventArgs e)
        {
            for(int i = 0; i < filesToRecover.Count; i++)
            {
                Block.blocks[filesToRecover[i]].deleted = false;
            }
            Block.generateFilesInfo();
            Close();
        }

        private void Cancel(object sender, RoutedEventArgs e)
        {
            filesToRecover.Clear();
            Close();
        }
    }
}
