﻿using System;
using Microsoft.Win32;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Diagnostics;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using Personal_Data_Vault;

namespace Personal_Data_Vault
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    ///

    public partial class MainWindow : Window
    {
        /* Constructor for the Search Bar, so that you can return the search text element. */
        public string SearchedTags
        {
            get
            {
                if (SearchBar == null) return string.Empty;
                return SearchBar.Text;
            }
        }

        public MainWindow()
        {


            InitializeComponent();

            // NEED TO ADD OPTION TO SEND AND RECEIVE FILES

            /* Checks to see if the user has a blockchain saved on their computer. If there is, load it. If not, create a genesis block. */
            if (!File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/blocks.dat"))
            {
                Block.CreateGenesisBlock();
                Files.ItemsSource = Block.filesInfo;
            }
            else
            {
                Block.Load();
                Block.generateFilesInfo();
                Files.ItemsSource = Block.filesInfo;
            }
        }

        /* Waits for the window to load before displaying any errors that were found. */
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Block.ShowError();
        }

        /* This button brings up a window with the files that can be recovered. */
        private void RecoverDeletedFiles(object sender, RoutedEventArgs e)
        {
            Block.recoveryFilesList = new List<RecoveryFilesInfo>();
            Block.generateRecoveryFilesList();
            Files.ItemsSource = Block.filesInfo;
            Files.InvalidateArrange();
            Files.Items.Refresh();
            Files.UpdateLayout();
        }

        /* This button brings up a window with the names of all of the files that are inacessible. */
        private void ShowInaccessibleFiles(object sender, RoutedEventArgs e)
        {
            Block.generateInaccessibleFilesList();

        }

        /* This button just searches for the tags of the files in their database. */
        private void SearchTags(object sender, RoutedEventArgs e)
        {
            Blockchain.SearchForTags();
            
            Files.ItemsSource = Block.filesInfo;
            Files.InvalidateArrange();
            Files.Items.Refresh();
            Files.UpdateLayout();
        }

        /* This button clears the search text box. */
        private void ClearSearch(object sender, RoutedEventArgs e)
        {
                Block.generateFilesInfo();

                Files.ItemsSource = Block.filesInfo;
                Files.InvalidateArrange();
                Files.Items.Refresh();
                Files.UpdateLayout();

                SearchBar.Text = string.Empty;

                Blockchain.hasSearched = false;
        }

        /* This reloads the whole list if the search bar is empty. It checks this on any text change in the search box. */
        private void UpdateList(object sender, RoutedEventArgs e)
        {

            bool update = Blockchain.CheckIfSearchBarIsEmpty();

            if (update == true)
            {
                Files.ItemsSource = Block.filesInfo;
                Files.InvalidateArrange();
                Files.Items.Refresh();
                Files.UpdateLayout();
            }

        }

        private void Make_Task_Click(object sender, RoutedEventArgs e)
        {
           // Block.tasks.Add(new dataSharedTask());
        }

        private void Task_Click(object sender, RoutedEventArgs e)
        {
            //TaskWindow tWin = new TaskWindow(0);
           // tWin.ShowDialog();
            // List<int> selectedIndices = tWin.selectedIndices;
        }

        private void Add_Block_Click(object sender, RoutedEventArgs e)
        {
            Block.DiagnoseBlockchainValidity();
            Block.ShowError();

            /*When adding a block, increment the blockIndex and set that block to have that index. */
            Block.blockIndex++;

            /* Get the hash of the previous block and set that as the previous hash value of the block being added. */
            Block.actualPreviousHash = Block.blocks[(Block.blockIndex) - 1].hash;

            /* Get the file hash of the previous block and set that as the previous file hash value of the block being added. */
            Block.actualPreviousFileHash = Block.blocks[(Block.blockIndex) - 1].fileHash;

            /* Add a block to the blockchain. */
            Blockchain.AddBlock(Block.blockIndex, Block.actualPreviousHash, 666, 2, DateTime.Now.ToString(), "signed", Block.actualPreviousFileHash); // Block.tag

            /* Set the list of Files on the app to be the blocks and then update it on the app. */
            Files.ItemsSource = Block.filesInfo;
            Files.InvalidateArrange();
            Files.Items.Refresh();
            Files.UpdateLayout();

        }

        /* This function for opening the pdf file of whatever button was clicked in their database. */
        private void Button_Click(object sender, RoutedEventArgs e)
        {

            Button button = sender as Button;
            FileInformation info = button.DataContext as FileInformation;
            string path = info.fullPathNameInfo;

            try
            {
                Process process = new Process();
                Uri pdf = new Uri(path, UriKind.RelativeOrAbsolute);
                process.StartInfo.FileName = pdf.LocalPath;
                Block.DiagnoseBlockchainValidity();
                Block.ShowError();
                process.Start();
                process.WaitForExit();
            }
            catch (Exception error)
            {
                MessageBox.Show("Could not open the file.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);

                /* If they click their file button and there's no file, then show them the error message. */
                Block.generateFilesInfo();
                /* Set the list of Files on the app to be the blocks and then update it on the app. */
                Files.ItemsSource = Block.filesInfo;
                Files.InvalidateArrange();
                Files.Items.Refresh();
                Files.UpdateLayout();
            }

        }

        /* This function brings up a window asking if they want to delete the file from their GUI. */
        private void Delete_Block(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            FileInformation info = button.DataContext as FileInformation;
            int index = info.index;

            //open up confirmDeleteWindow on the block
            ConfirmDeleteWindow win = new ConfirmDeleteWindow(Block.blocks[index]);
            win.ShowDialog();

            Files.ItemsSource = Block.filesInfo;
            Files.InvalidateArrange();
            Files.Items.Refresh();
            Files.UpdateLayout();
        }

        /* This button brings up a window that shows all of the tags associated with whatever block the button was associated with. */
        private void Show_Tags(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            FileInformation info = button.DataContext as FileInformation;
            int index = info.index;
            Console.WriteLine("Button index:" + index);

            ShowTags showTagsWindow = new ShowTags(index);
            showTagsWindow.ShowDialog();

        }
    }
}
