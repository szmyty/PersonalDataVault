﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Personal_Data_Vault
{
    /// <summary>
    /// Interaction logic for InaccessibleFiles.xaml
    /// </summary>
    public partial class InaccessibleFiles : Window
    {
        public InaccessibleFiles()
        {
            InitializeComponent();

            InaccessibleFilesList.ItemsSource = Block.inaccessibleFilesList;
            InaccessibleFilesList.InvalidateArrange();
            InaccessibleFilesList.Items.Refresh();
            InaccessibleFilesList.UpdateLayout();
        }
    }
}
