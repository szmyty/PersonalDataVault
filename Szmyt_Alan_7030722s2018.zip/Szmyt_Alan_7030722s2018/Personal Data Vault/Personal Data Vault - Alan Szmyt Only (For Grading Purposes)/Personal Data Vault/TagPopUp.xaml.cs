﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Personal_Data_Vault
{
    /// <summary>
    /// Interaction logic for TagPopUp.xaml
    /// </summary>
    public partial class TagPopUp : Window
    {
        public string UserTags
        {
            get
            {
                if (TagsTextBox == null) return string.Empty;
                return TagsTextBox.Text;
            }
        }

        public TagPopUp()
        {
            InitializeComponent();
            TagsTextBox.Focus();
        }

        private void AddTagsClick(object sender, RoutedEventArgs e)
        { 
            Close();
        }
    }
}

