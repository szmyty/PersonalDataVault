﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Personal_Data_Vault
{
    /// <summary>
    /// Interaction logic for IllegallyChangedFiles.xaml
    /// </summary>
    public partial class IllegallyChangedFiles : Window
    {
        public IllegallyChangedFiles()
        {
            InitializeComponent();

            ChangedFiles.ItemsSource = Block.illegallyChangedFiles;
            ChangedFiles.InvalidateArrange();
            ChangedFiles.Items.Refresh();
            ChangedFiles.UpdateLayout();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Block.generateFilesInfo();
        }
    }
}
