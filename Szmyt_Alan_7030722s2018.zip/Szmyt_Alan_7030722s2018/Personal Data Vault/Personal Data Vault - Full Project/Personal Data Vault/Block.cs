﻿/* Block.cs -- Personal Data Vault
 * Programmers - Alan Szmyt and Matthew Pelland 
 * 
 */
using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using Microsoft.Win32;
using System.Windows;
using System.Windows.Input;
using System.Threading.Tasks;

namespace Personal_Data_Vault
{

    #region Block
    /********      Block Class       ********/
    /*                                      */
    /*                                      */
    /*                                      */
    /****************************************/

    [Serializable]
    /* Block Class */
    public class Block
    {
        internal int index;
        internal string previousHash;
        internal int data;
        internal int creator;
        internal string hash;
        internal string timestamp;
        internal string fullPathToFile;
        internal string fullFileName;
        internal bool deleted;
        internal bool accessibility;
        internal string fileHash;
        internal string previousFileHash;
        public static int userID;
        public static string actualPreviousHash;
        public static string actualPreviousFileHash;
        public static int blockIndex;
        public static List<Block> blocks;
        public static List<KeyValuePair<String, int>> tags;
        public static List<Task> tasks;
        public static List<FileInformation> filesInfo;
        public static List<TagsInformation> tagsInfo;
        public static List<illegallyChangedFilesInfo> illegallyChangedFiles;
        public static List<FilesNotFoundInfo> filesNotFound;
        public static List<RecoveryFilesInfo> recoveryFilesList;
        public static List<InaccessibilityInfo> inaccessibleFilesList;

        /* Block Constructor */
        public Block(int newIndex, string newPreviousHash, int newData, int newCreator, string newTimeStamp, string newFullPathToFile, string newFullFileName, bool isDeleted, bool isAccessible, string newPreviousFileHash)
        {
            index = newIndex;
            previousHash = newPreviousHash;
            data = newData;
            creator = newCreator; // username (to be integrated later).
            timestamp = newTimeStamp; //Get current time and sets it to the block.
            fullPathToFile = newFullPathToFile;
            fullFileName = newFullFileName;
            hash = CalculateHash(); //Calculate Hash of the blocks data.
            deleted = isDeleted;
            accessibility = isAccessible; //Boolean to decide if the file can be accessed or not.
            previousFileHash = newPreviousFileHash;
            fileHash = CalculateFileHash(fullPathToFile);
        }

        /* Creates genesis block of default values as the first Block in the Blockchain */
        public static void CreateGenesisBlock()
        {
            /* If the file doesn't exist yet, create the directory to place the blockchain data in. */
            if (!File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault"))
            {
                Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault");
                /* Also, create a folder files are saved to. */
                Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/Portfolio");
                /* Create a file to use as the genesis file hash. */
                FileStream tempFile = File.Create(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/temp.txt");
                tempFile.Close();
            }

            tasks = new List<Task>();

            /* Create the genesis block with default values */
            blocks = new List<Block>(); // This is the user's Blockchain as a list.

            tags = new List<KeyValuePair<String, int>>();
            tags.Add(new KeyValuePair<String, int>("", 0));

            /* This is an overarching block index that is saved, so that when a new block is added after the program is shut down, it will know where to start from. */
            blockIndex = 0;

            /* Creates a temp text file to take a file hash for the genesis block. */
            string genesisFileHash = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/temp.txt";

            /* Empty block to start as genesis block. */
            blocks.Add(new Block(blockIndex, "", 0, 0, DateTime.Now.ToString(), genesisFileHash, "Welcome to Your Personal Data Vault", true, false, "")); // tag

            /* Create the filesInfo list for data binding purposes */
            filesInfo = new List<FileInformation>();

            /* Create the tagInfo list for data binding purposes */
            tagsInfo = new List<TagsInformation>();

            /* Create the inaccessibleFilesList list for data binding purposes */
            inaccessibleFilesList = new List<InaccessibilityInfo>();

            /* Initializing the lists for data binding. */
            illegallyChangedFiles = new List<illegallyChangedFilesInfo>();
            filesNotFound = new List<FilesNotFoundInfo>();
            recoveryFilesList = new List<RecoveryFilesInfo>();

            /* Create dummy tasks for testing purposes. */
            createTask(taskType.BLOCK_ADDITION_RECEIVED_TASK, 0, "block addition received task");
            createTask(taskType.BLOCK_ADDITION_REQUEST_TASK, 0, "block addition request task");
            createTask(taskType.DATA_REQUESTED_TASK, 0, "Data requested task");
            createTask(taskType.DATA_SHARED_TASK, 0, "data shared task");
			
			/* Create fake folder of data sent over. */
            Directory.CreateDirectory(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/sharedData");
            FileStream file = File.Create(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/sharedData/example1.pdf");
            file.Close();
            FileStream file2 = File.Create(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/sharedData/example2.pdf");

        }

        /* This function is called by CalculateHash to return a hash of the given string */
        public static string SHA256(string inputString)
        {
            SHA256Managed mySHA256 = new SHA256Managed();
            StringBuilder hash = new StringBuilder();
            byte[] hashValue = mySHA256.ComputeHash(Encoding.UTF8.GetBytes(inputString), 0, Encoding.UTF8.GetByteCount(inputString));
            foreach (byte theByte in hashValue)
            {
                hash.Append(theByte.ToString("x2"));
            }
            return hash.ToString();
        }

        /* This calculates the hash that will be specific to the block by using SHA256*/
        public string CalculateHash()
        {
            /* Gets the information of the block and creates a string of it, then gets the hash of that string */
            string collect = index.ToString() + previousHash + data.ToString() + creator + timestamp + fullPathToFile + fullFileName;
            return SHA256(collect);
        }

        /* This calculates the hash of the actual file using the filePath given. */
        public static string CalculateFileHash(string filePath)
        {
            HashAlgorithm cryptoService = new SHA256CryptoServiceProvider();

            using (cryptoService)
            {
                using (var fileStream = new FileStream(filePath,
                                                       FileMode.Open,
                                                       FileAccess.Read,
                                                       FileShare.ReadWrite))
                {
                    var hash = cryptoService.ComputeHash(fileStream);
                    var hashString = Convert.ToBase64String(hash);
                    return hashString.TrimEnd('=');
                }
            }
        }

        /* This function checks to see if the blockchain is valid. */
        public static bool IsChainValid()
        {
            bool validity = true;

            for(int i = 1; i < Block.blocks.Count; i++)
            {
                if(IsBlockValid(i) == false)
                {
                    validity = false;
                }
            }
            return validity;
          
        }

        /* This function checks to see if the block itself is valid. */
        public static bool IsBlockValid(int index)
        {
            /* Check that block information is correct. */
            string collect = blocks[index].index.ToString() + blocks[index].previousHash + blocks[index].data.ToString() + blocks[index].creator + blocks[index].timestamp + blocks[index].fullPathToFile + blocks[index].fullFileName;
            string hashAgain = SHA256(collect);
            string path = blocks[index].fullPathToFile;
            bool blockValidity = true;

            /* Hash the data again to make sure that it matches the hash that was originally created. */
            if (hashAgain != blocks[index].hash)
            {
                Console.WriteLine("hash didn't match hash again");
                blockValidity = false;
            } else if (index != (blocks[index-1].index + 1))
            {
                Console.WriteLine("block indexing is wrong.");
                blockValidity = false;
            } else if (blocks[index].previousHash != blocks[index-1].hash)
            {
                Console.WriteLine("actual hash of previous block does not match previoushash field of this block.");
                blockValidity = false;
            }

            /* Make sure to check if the file path exists because taking a file hash of nothing will give an error. */
            if (File.Exists(path))
            {
                /* Check that stored files are correct. */
                if (CalculateFileHash(path) != blocks[index].fileHash)
                {
                    /* The file has been illegally changed. */
                    //Console.WriteLine("file has been changed as hashes do not match.");

                    /* This check is to see if the file has already been changed to inaccessible. If it has we don't want to prompt them everytime the program loads. */
                    if (blocks[index].accessibility == true && blocks[index].deleted == false)
                    {
                        blocks[index].accessibility = false;
                        blocks[index].deleted = true;

                        /* Adds to the list of illegally changed files to be displayed to the user. */
                        illegallyChangedFiles.Add(new illegallyChangedFilesInfo() { changedFilesInfo = blocks[index].fullFileName });
                    }

                    //blockValidity = false;
                }
            }
            else
            {
                /* File doesn't exist at the given path. */
                //Console.WriteLine("file cannot be found at the given path.");

                /* This check is to see if the file has already been changed to inaccessible. If it has we don't want to prompt them everytime the program loads. */
                if (blocks[index].accessibility == true && blocks[index].deleted == false)
                { 
                    blocks[index].accessibility = false;
                    blocks[index].deleted = true;

                    /* Adds to the list of files that weren't found to be displayed to the user. */
                    filesNotFound.Add(new FilesNotFoundInfo() { missingFilesInfo = blocks[index].fullFileName });               
                }
            }

            return blockValidity;
  
        }

        /* This function saves the blockchain onto the local harddrive of the user's compter. */
        public static void Save()
        {
            /* This function is for saving the blocks to a file */
            BinaryFormatter bf = new BinaryFormatter();
            FileStream file = File.Create(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/blocks.dat");

            /* This basically creates a copy of the blockchain to be saved to the data file. */
            BlockData data = new BlockData();
            data.blocks = blocks;

            /* Serializes the data to the file */
            bf.Serialize(file, data);
            file.Close();

            /* This section is for saving the file information to a file */
            BinaryFormatter bf2 = new BinaryFormatter();
            FileStream file2 = File.Create(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/fileinfo.dat");

            /* This basically creates a copy of the filesinfo to be saved to the data file. This is the data binding list. */
            FileInformationData data2 = new FileInformationData();
            data2.filesInfo = filesInfo;

            /* Serializes the data to the file */
            bf2.Serialize(file2, data2);
            file2.Close();

            /* This section is for saving the tags to a file */
            BinaryFormatter bf3 = new BinaryFormatter();
            FileStream file3 = File.Create(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/tags.dat");

            /* This basically creates a copy of the tags to be saved to the data file. */
            BlockData data3 = new BlockData();
            data3.tags = tags;

            /* Serializes the data to the file */
            bf3.Serialize(file3, data3);
            file3.Close();

            /* This section is for saving the tags to a file */
            BinaryFormatter bf4 = new BinaryFormatter();
            FileStream file4 = File.Create(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/tagsInfo.dat");

            /* This basically creates a copy of the tagsInfo to be saved to the data file. This is for data binding. */
            BlockData data4 = new BlockData();
            data4.tagsInfo = tagsInfo;

            /* Serializes the data to the file */
            bf4.Serialize(file4, data4);
            file4.Close();

            /* This function is for saving the blockIndex to a file */
            BinaryFormatter bf5 = new BinaryFormatter();
            FileStream file5 = File.Create(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/blockIndex.dat");

            /* This basically creates a copy of the blockIndex to be saved to the data file.  */
            BlockData data5 = new BlockData();
            data5.blockIndex = blockIndex;

            /* Serializes the data to the file */
            bf5.Serialize(file5, data5);
            file5.Close();

            /* This section is for saving the inaccessible files list to a file */
            BinaryFormatter bf6 = new BinaryFormatter();
            FileStream file6 = File.Create(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/inaccessible.dat");

            /* This basically creates a copy of the inaccessibleList to be saved to the data file. */
            BlockData data6 = new BlockData();
            data6.inaccessibleList = inaccessibleFilesList;

            /* Serializes the data to the file */
            bf6.Serialize(file6, data6);
            file6.Close();

            /* Save the tasks to a file. */
            BinaryFormatter bf7 = new BinaryFormatter();
            FileStream file7 = File.Create(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/tasks.dat");

            BlockData data7 = new BlockData();
            data7.tasks = tasks;

            bf7.Serialize(file7, data7);
            file7.Close();
        }

        /* This function is for loading up the blocks */
        public static void Load()
        {
            /* Check to see if the file even exists, if it does, load up the blockchain */
            if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/blocks.dat"))
            {
                BinaryFormatter bf = new BinaryFormatter();
                FileStream file = File.Open(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/blocks.dat", FileMode.Open);
                /* Deserialize the data, so that it is actually accessible as a list object again */
                BlockData data = (BlockData)bf.Deserialize(file);
                file.Close();
                /* Set the copy of the blockchain to the actual blockchain that is going to be manipulated and used */
                blocks = data.blocks;
            }

            /* Check to see if the file even exists, if it does, load up the files information */
            if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/fileinfo.dat"))
            {
                BinaryFormatter bf = new BinaryFormatter();
                FileStream file = File.Open(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/fileinfo.dat", FileMode.Open);
                /* Deserialize the data, so that it is actually accessible as a list object again */
                FileInformationData data = (FileInformationData)bf.Deserialize(file);
                file.Close();
                /* Set the copy of the filesInfo to the actual filesInfo list that is going to be manipulated and used */
                filesInfo = data.filesInfo;
            }

            /* Check to see if the file even exists, if it does, load up the files information */
            if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/tags.dat"))
            {
                BinaryFormatter bf = new BinaryFormatter();
                FileStream file = File.Open(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/tags.dat", FileMode.Open);
                /* Deserialize the data, so that it is actually accessible as a list object again */
                BlockData data = (BlockData)bf.Deserialize(file);
                file.Close();
                /* Set the copy of the tags to the actual tags list that is going to be manipulated and used */
                tags = data.tags;
            }

            /* Check to see if the file even exists, if it does, load up the files information */
            if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/tagsInfo.dat"))
            {
                BinaryFormatter bf = new BinaryFormatter();
                FileStream file = File.Open(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/tagsInfo.dat", FileMode.Open);
                /* Deserialize the data, so that it is actually accessible as a list object again */
                BlockData data = (BlockData)bf.Deserialize(file);
                file.Close();
                /* Set the copy of the tagsInfo to the actual tagsInfo list that is going to be manipulated and used */
                tagsInfo = data.tagsInfo;
            }

            if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/tasks.dat"))
            {
                BinaryFormatter bf = new BinaryFormatter();
                FileStream file = File.Open(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/tasks.dat", FileMode.Open);
                /* Deserialize the data, so that it is actually accessible as a list object again */
                BlockData data = (BlockData)bf.Deserialize(file);
                file.Close();
                /* Set the copy of the tasks to the actual tasks list that is going to be manipulated and used */
                tasks = data.tasks;
            }

            if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/blockIndex.dat"))
            {
                BinaryFormatter bf = new BinaryFormatter();
                FileStream file = File.Open(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/blockIndex.dat", FileMode.Open);
                /* Deserialize the data, so that it is actually accessible as a list object again */
                BlockData data = (BlockData)bf.Deserialize(file);
                file.Close();
                /* Set the copy of the blockIndex to the actual blockIndex that is going to be manipulated and used */
                blockIndex = data.blockIndex;
            }

            /* Check to see if the file even exists, if it does, load up the files information */
            if (File.Exists(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/inaccessible.dat"))
            {
                BinaryFormatter bf = new BinaryFormatter();
                FileStream file = File.Open(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/inaccessible.dat", FileMode.Open);
                /* Deserialize the data, so that it is actually accessible as a list object again */
                BlockData data = (BlockData)bf.Deserialize(file);
                file.Close();
                /* Set the copy of the inacessibleList to the actual inacessibleList list that is going to be manipulated and used */
                inaccessibleFilesList = data.inaccessibleList;
            }

            if (blocks.Count > 0)
            {
                illegallyChangedFiles = new List<illegallyChangedFilesInfo>();
                filesNotFound = new List<FilesNotFoundInfo>();
                DiagnoseBlockchainValidity();
            }
        }

        /* This function is called to check the blockchain validity. This happens when blocks are added, deleted, or changed and when the program first loads up. */
        public static void DiagnoseBlockchainValidity()
        {
            illegallyChangedFiles.Clear();
            filesNotFound.Clear();
            string isChainValid = IsChainValid().ToString();
            Console.WriteLine("blockchain validity is: " + isChainValid);
        }

        /* This function shows the error window for either files not being found and/or illegally changed files. */
        public static void ShowError()
        {
            if (filesNotFound.Count > 0)
            {
                FilesNotFound filesNotFoundWindow = new FilesNotFound();
                filesNotFoundWindow.ShowDialog();
            }

            if (illegallyChangedFiles.Count > 0)
            {
                IllegallyChangedFiles changedFilesWindow = new IllegallyChangedFiles();
                changedFilesWindow.ShowDialog();
            }
        }

        /* This function deletes a file from the GUI by making the deleted boolean true. Recoverable. */
        public static void deleteBlock(int index)
        {
            blocks[index].deleted = true;
            DiagnoseBlockchainValidity();
            ShowError();
            generateFilesInfo();
        }

        /* This function updates the filesInfo list with the newest list that should be displayed in the GUI. */
        public static void generateFilesInfo()
        {
            filesInfo.Clear();
            for (int i = 0; i < blocks.Count; i++)
            {
                if (!blocks[i].deleted)
                    filesInfo.Add(new FileInformation() { fullFileNameInfo = blocks[i].fullFileName, fullPathNameInfo = blocks[i].fullPathToFile, timestampInfo = blocks[i].timestamp, index = blocks[i].index });
            }
            Save();
        }

        /* This function is to create a task. */
       //currently creates dummy tasks.  In reality this will be passed real data and will need to be changed
        public static void createTask(taskType type, int other, string message) {
            switch (type) {
                case taskType.BLOCK_ADDITION_RECEIVED_TASK:
                    FileStream file = File.Create(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/TotallyAFile.pdf");
                    file.Close();
                    blockIndex++;
                    Block.blocks.Add(new Block(blockIndex, Block.blocks[Block.blocks.Count - 1].hash, 0, 0, DateTime.Now.ToString(), Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/TotallyAFile.pdf", "TotallyAFile", true, false, Block.blocks[Block.blocks.Count - 1].fileHash));
                    FileStream file2 = File.Create(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/TotallyAFile2.pdf");
                    file2.Close();
                    blockIndex++;
                    Block.blocks.Add(new Block(blockIndex, Block.blocks[Block.blocks.Count - 1].hash, 0, 0, DateTime.Now.ToString(), Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/TotallyAFile2.pdf", "TotallyAFile2", true, false, Block.blocks[Block.blocks.Count - 1].fileHash));

                    List<int> blocks = new List<int>();
                    blocks.Add(Block.blocks.Count - 2);
                    blocks.Add(Block.blocks.Count - 1);
                    List<string> data = new List<string>();
                    tasks.Add(new BlockAdditionReceivedTask(other, message, blocks, data));
                    break;
                case taskType.BLOCK_ADDITION_REQUEST_TASK:
                    //this one's nice and simple yay
                    tasks.Add(new BlockAdditionRequestTask(other, message, null, null));
                    break;
                case taskType.DATA_REQUESTED_TASK:
                    //nother user requested data, once again simple
                    tasks.Add(new DataRequestedTask(other, message, null, null));
                    break;
                case taskType.DATA_SHARED_TASK:
                    //nother user shared date.  Would be stored in a separate temp folder for "<user_id>DataShared." Will write code to do that
                    tasks.Add(new dataSharedTask(other, message, null, null));
                    break;
                default:
                    break;

            }
        }
    

        /* This function generates the files list to show on the Inaccessibles Files Window. */
        public static void generateInaccessibleFilesList()
        {
            inaccessibleFilesList.Clear();
            for (int i = 1; i < blocks.Count; i++)
            {
                Console.WriteLine(blocks[i].accessibility);
                if (!blocks[i].accessibility)
                    inaccessibleFilesList.Add(new InaccessibilityInfo() { inaccessibilityInfo = blocks[i].fullFileName });
            }

            InaccessibleFiles inaccessibleFilesWindow = new InaccessibleFiles();
            inaccessibleFilesWindow.ShowDialog();
        }

        /* This function generates the files list that is available for recovery. */
        public static void generateRecoveryFilesList()
        {
            recoveryFilesList.Clear();
            for (int i = 1; i < blocks.Count; i++)
            {
                if (blocks[i].accessibility == true && blocks[i].deleted == true)
                {
                    recoveryFilesList.Add(new RecoveryFilesInfo() { recoveryFiles = blocks[i].fullFileName, recoveryFileIndex = blocks[i].index });
                }
            }

            RecoverDeletedFiles recoverDeletedFilesWindow = new RecoverDeletedFiles();
            recoverDeletedFilesWindow.ShowDialog();
        }
    }

    #endregion

    #region Blockchain
    /********    Blockchain Class    ********/
    /*                                      */
    /*                                      */
    /*                                      */
    /****************************************/

    public class Blockchain
    {
        public static bool hasSearched = false;

        /* Returns the length of the user's blockchain */
        public int BlockchainLength()
        {
            return Block.blocks.Count();
        }

        /* Adds a block to the blockchain */
        public static void AddBlock(int index, string previousHash, int data, int creator, string timestamp, string signature, string previousFileHash) // List<Tags> tags
        {

            /* Let the user open a file that they want to add to their blockchain. */
            OpenFileDialog openFile = new OpenFileDialog();
            /* Only allow one file per block. */
            openFile.Multiselect = false;
            openFile.Title = "Open File";
            openFile.Filter = "PDF Files (*.pdf)|*.pdf";

            /* Once they click "Open" for the file that they want, copy it to the Portfolio directory. */
            if (openFile.ShowDialog() == true)
            {
                int count = 1;
                string finalFileName = "";
                string sourcePath = openFile.FileName;
                string fileName = openFile.SafeFileName;
                string targetPath = (Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/Portfolio/" + fileName);
                string newFullPath = targetPath;
                string extension = Path.GetExtension(targetPath);
                string path = Path.GetDirectoryName(targetPath);
                string fileNameNoEXT = Path.GetFileNameWithoutExtension(openFile.FileName);

                /* Check to see if the file exists and if it does rename it to a copy. */
                while (File.Exists(newFullPath))
                {
                    string tempFileName = string.Format("{0}({1})", fileNameNoEXT, count++);
                    newFullPath = Path.Combine(path, tempFileName + extension);
                    finalFileName = tempFileName;
                }
                while (!File.Exists(newFullPath))
                {
                    File.Copy(sourcePath, newFullPath, false);
                    if (!(finalFileName == ""))
                    {
                        Console.WriteLine(newFullPath + "" + finalFileName);
                    }
                    else
                    {
                        finalFileName = fileNameNoEXT;
                        Console.WriteLine(newFullPath + "" + fileName);
                    }
                }

                /* Prompts the user with a popup to ask them to input tags relating to the document */
                TagPopUp popup = new TagPopUp();
                popup.ShowDialog();
                string result = popup.UserTags;
                popup.TagsTextBox.Text = result;
                
                /* Separate the tags by comma and create a list of them. */
                List<string> tagsFromInput = result.Split(',').ToList<string>();

                /* Get all the tags that they inputted, trim the extra spaces in the beginning and then add it to the block's Tags list. */
                for (int i = 0; i <= tagsFromInput.Count - 1; i++)
                {
                    tagsFromInput[i] = tagsFromInput[i].TrimStart();
                    Block.tags.Add(new KeyValuePair<string, int>(tagsFromInput[i], Block.blockIndex));
                }

                for (int j = 0; j <= Block.tags.Count - 1; j++)
                {
                    //Console.WriteLine(Block.tags[j].Value);
                }

                /* Adds the actual block information to the blockchain. */
                Block.blocks.Add(new Block(index, previousHash, data, creator, timestamp, newFullPath, finalFileName, false, true, previousFileHash)); 

                Block.filesInfo.Add(new FileInformation() { fullFileNameInfo = finalFileName, fullPathNameInfo = newFullPath, timestampInfo = timestamp, index = index });

            }
            else
            {
                //Console.WriteLine("pressed cancel");
                /* If they press cancel, then decrement the blockIndex to make sure it's not out of range for the next addition. */
                Block.blockIndex--;
            }
            /* Save the updated blockchain to their system */
            Console.WriteLine(Block.blockIndex);
            Block.Save();
        }

        /* Uses the index of the document of which was selected to show the tags. Finds the tags associated with that block and prints them to a new window. */
        public static void FindTagsToShow(int index)
        {
            /* Clear TagsInfo list to display only the tags associated with the block index of the button clicked. */
            Block.tagsInfo.Clear();

            //Console.WriteLine("Count: " + Block.tagsInfo.Count);

            /* Tags with this index as their value will be shown. */
            int tagsToSearchFor = index;

            //Console.WriteLine("index " + tagsToSearchFor);

            var lookup = Block.tags.Where(kvp => kvp.Value.Equals(tagsToSearchFor)).ToList();

            for(int i = 0; i < lookup.Count; i++)
            {
                Block.tagsInfo.Add(new TagsInformation() { tagInfo = lookup[i].Key });
            }

        }

        /* This function is used to search for the tags associated to each document and to display the ones that have those associations. */
        public static void SearchForTags()
        {
            MainWindow mw = (MainWindow)Application.Current.MainWindow;
            string result = mw.SearchedTags;
            mw.SearchBar.Text = result;

            if (result != string.Empty)
            {
                if (Convert.ToBoolean(mw.SearchByTags.IsChecked))
                {
                    var lookup = Block.tags.Where(kvp => kvp.Key.ToLower().StartsWith(result.ToLower())).ToList();

                    lookup = lookup.GroupBy(s => s.Value).Select(g => g.First()).ToList();

                    Block.filesInfo.Clear();

                    for (int i = 0; i < lookup.Count; i++)
                    {
                        int lookupIndex = lookup[i].Value;
                        if (!Block.blocks[lookupIndex].deleted)
                        {
                            Block.filesInfo.Add(new FileInformation() { fullFileNameInfo = Block.blocks[lookupIndex].fullFileName, fullPathNameInfo = Block.blocks[lookupIndex].fullPathToFile, timestampInfo = Block.blocks[lookupIndex].timestamp, index = Block.blocks[lookupIndex].index });
                        }
                    }
                    hasSearched = true;
                }
                else if (Convert.ToBoolean(mw.SearchByFileName.IsChecked))
                {
                    var lookup = Block.blocks.Where(kvp => kvp.fullFileName.ToLower().Contains(result.ToLower())).ToList();

                    Block.filesInfo.Clear();

                    for (int i = 0; i < lookup.Count; i++)
                    {
                        int lookupIndex = lookup[i].index;
                        if (!Block.blocks[lookupIndex].deleted)
                        {
                            Block.filesInfo.Add(new FileInformation() { fullFileNameInfo = Block.blocks[lookupIndex].fullFileName, fullPathNameInfo = Block.blocks[lookupIndex].fullPathToFile, timestampInfo = Block.blocks[lookupIndex].timestamp, index = Block.blocks[lookupIndex].index });
                        }
                    }
                    /* This boolean is for determining how the search bar looks (empty or not). */
                    hasSearched = true;
                }
            }
        }

        /* This function checks to see if the search bar is empty, so that all files can get loaded back up to the GUI. */
        public static bool CheckIfSearchBarIsEmpty()
        {
            //bool hasChanged = false;
            bool generateFilesCalled = false;

            MainWindow mw = (MainWindow)Application.Current.MainWindow;
            string result = mw.SearchedTags;
            mw.SearchBar.Text = result;

            if(result == string.Empty && Blockchain.hasSearched == true)
            {
                Block.generateFilesInfo();
                generateFilesCalled = true;
                Console.WriteLine(generateFilesCalled);
            }

            return generateFilesCalled;
        }
    }

    #endregion

    #region FileInformation
    /*****    File Information Class    *****/
    /*                                      */
    /*                                      */
    /*                                      */
    /****************************************/


    [Serializable]
    public class FileInformation
    {
        public string timestampInfo { get; set; }
        public string fullFileNameInfo { get; set; }
        public string fullPathNameInfo { get; set; }
        public int index { get; set; }
    }

    #endregion

    #region TagsInfo
    /********     TagsInfo Class     ********/
    /*                                      */
    /*                                      */
    /*                                      */
    /****************************************/

    [Serializable]
    public class TagsInformation
    {
        public string tagInfo { get; set; }
    }

    #endregion

    #region InaccessibilityInfo
    /*****    InaccessibilityInfo Class    *****/
    /*                                      */
    /*                                      */
    /*                                      */
    /****************************************/


    [Serializable]
    public class InaccessibilityInfo
    {
        public string inaccessibilityInfo { get; set; }
    }

    #endregion

    #region FilesNotFoundInfo
    /*****    FilesNotFoundInfo Class    *****/
    /*                                      */
    /*                                      */
    /*                                      */
    /****************************************/

    public class FilesNotFoundInfo
    {
        public string missingFilesInfo { get; set; }
    }

    #endregion

    #region illegallyChangedFilesInfo
    /*****    illegallyChangedFilesInfo Class    *****/
    /*                                      */
    /*                                      */
    /*                                      */
    /****************************************/

    public class illegallyChangedFilesInfo
    {
        public string changedFilesInfo { get; set; }
    }

    #endregion

    #region RecoveryFilesInfo
    /*****    RecoveryFilesInfo Class    *****/
    /*                                      */
    /*                                      */
    /*                                      */
    /****************************************/

    public class RecoveryFilesInfo
    {
        public string recoveryFiles { get; set; }
        public int recoveryFileIndex { get; set; }
    }

    #endregion

    #region BlockData
    /* This is a copy of the blocks to be saved or loaded */
    [Serializable]
    class BlockData
    {
        public List<Block> blocks;
        public List<KeyValuePair<String, int>> tags;
        public List<TagsInformation> tagsInfo;
        public int blockIndex;
        public List<InaccessibilityInfo> inaccessibleList;
        public List<Task> tasks;
    }

    #endregion

    #region FileInformationData
    [Serializable]
    class FileInformationData
    {
        public List<FileInformation> filesInfo;
    }
    #endregion
}