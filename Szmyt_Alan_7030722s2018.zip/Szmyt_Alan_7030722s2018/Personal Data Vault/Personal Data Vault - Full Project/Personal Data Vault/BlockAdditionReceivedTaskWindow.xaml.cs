﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace Personal_Data_Vault
{
    [Serializable]
    public partial class BlockAdditionReceivedTaskWindow : Window
    {
        //each window stores its associated Task 
        Task associatedTask;
        //collection of all checkboxes for selected which blocks to add
        public ObservableCollection<BlockCheckBox> checkBlocks { get; set; }

        public BlockAdditionReceivedTaskWindow(int taskIndex)
        {
            checkBlocks = new ObservableCollection<BlockCheckBox>();
            associatedTask = Block.tasks[taskIndex];
            //These blocks are automatically added when the task is created, but are preemptively deleted unless selected
            foreach (int blockIndex in associatedTask.associatedBlocks) {
                checkBlocks.Add(new BlockCheckBox(Block.blocks[blockIndex].fullFileName, blockIndex));
            }
            //lets us access checkBlocks in the xaml
            DataContext = this;
            InitializeComponent();
        }

        private void Finish_Task(object sender, RoutedEventArgs e){
            foreach(BlockCheckBox checkBox in checkBlocks) {
                if (checkBox.IsChecked) {
                    Console.WriteLine(checkBox.index);
                    Block.blocks[checkBox.index].deleted = false;
                    Block.blocks[checkBox.index].accessibility = true;
                }
            }
            //regenerate filesInfo as some blocks may no longer be deleted
            Block.generateFilesInfo();
            Close();
        }
        private void Save_Task_Click(object sender, RoutedEventArgs e) {  
            //will finish implementing this in a bit.  Will be kind of obnoxious
            Close();
        }
    }
}
