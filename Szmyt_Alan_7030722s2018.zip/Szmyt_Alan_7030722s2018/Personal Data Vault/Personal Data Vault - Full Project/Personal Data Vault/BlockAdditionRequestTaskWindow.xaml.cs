﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Collections.ObjectModel;
using Microsoft.Win32;

namespace Personal_Data_Vault
{
    [Serializable]
    public partial class BlockAdditionRequestTaskWindow : Window
    {
        //actual filenames
        public List<string> files { get; set; }
        //checkboxes to select which files to actually send to other user
        public ObservableCollection<FileCheckBox> checkFiles { get; set; }
        int taskIndex { get; set; }
        public Task taskInSession { get; set; }
        public BlockAdditionRequestTaskWindow(int whatTask)
        {
            InitializeComponent();
            files = new List<string>();
            checkFiles = new ObservableCollection<FileCheckBox>();
            taskInSession = Block.tasks[whatTask];
            taskIndex = whatTask;
            DataContext = this;
        }

        void uploadFile(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Multiselect = true;
            openFile.Title = "Open File";
            openFile.Filter = "PDF Files (*.pdf)|*.pdf";
            if (openFile.ShowDialog() == true)
            {
                foreach (string filename in openFile.FileNames)
                {
                    files.Add(filename);
                    checkFiles.Add(new FileCheckBox(filename, 0, true));
                }
            }
            return;
        }


        //commented out bits will need to exist in actual implementation in some form
        void Finish_Task(object sender, RoutedEventArgs e)
        {
            //string lasthash = other_user.getLatestHash();
            List<Block> newBlocks = new List<Block>();
            string lastHash = "";//other_user.getLatestHash();
            string lastFileHash = "";//other_user.getLatestFileHash();
            int lastIndex = 0;//other_user.getBlockchainLength();
            foreach (string file in files)
            {
                //make block based on latest hash using file
                Block newBlock = new Block(lastIndex, lastHash, 0, Block.userID, DateTime.Now.ToString(), file, file, false, true, lastFileHash);
                newBlocks.Add(newBlock);
                lastHash = newBlock.hash;
                lastIndex++;
            }
            //send array of blocks to other user somehow, initiating BlockAdditionReceivedTask for them
            Close();
            
        }
    }
}



/*

namespace Personal_Data_Vault
{
    /// <summary>
    /// Interaction logic for BlockAdditionRequestTaskWindow.xaml
    /// </summary>
    /// 
    //other user has requested you to add a block to their blockchain

    [Serializable]
    public partial class BlockAdditionRequestTaskWindow : Window
    {
        public ObservableCollection<FileCheckBox> checkFiles;
        int taskIndex { get; set; }
        public Task taskInSession { get; set; }
        public List<string> files;

        public BlockAdditionRequestTaskWindow(int whatTask)
        {
            checkFiles = new ObservableCollection<FileCheckBox>();
            InitializeComponent();
            taskInSession = Block.tasks[whatTask];
            taskIndex = whatTask;
            files = new List<string>();
            checkFiles.Add(new FileCheckBox("bleagh", 0));
            DataContext = this;
        }
        void uploadFile(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Multiselect = true;
            openFile.Title = "Open File";
            openFile.Filter = "PDF Files (*.pdf)|*.pdf";
            if (openFile.ShowDialog() == true) {
                foreach (string filename in openFile.FileNames)
                {
                    files.Add(filename);
                    checkFiles.Add(new FileCheckBox(filename, 0));
                }
            }
            return;
        }

        void Finish_Task(object sender, RoutedEventArgs e) {
            //string lasthash = other_user.getLatestHash();
            List < Block > newBlocks = new List<Block>();
            string lastHash = "";//other_user.getLatestHash();
            int lastIndex = 0;//other_user.getBlockchainLength();
            foreach (string file in files) {
                //make block based on latest hash using file
                Block newBlock = new Block(lastIndex, lastHash, 0, Block.userID, DateTime.Now.ToString(), file, file, false);
                newBlocks.Add(newBlock);
                lastHash = newBlock.hash;
                lastIndex++;
            }
            //send array of blocks to other user somehow, initiating BlockAdditionReceivedTask for them
        }

        void Save_Task_Click(object sender, RoutedEventArgs e) {
            //store the data just as in the other tasks.  This should actually be the same for all tasks I would argue
            taskInSession.associatedData = files;
            Block.tasks[taskIndex] = taskInSession;
            Block.Save();
            Close();
        }
    }
}
*/
