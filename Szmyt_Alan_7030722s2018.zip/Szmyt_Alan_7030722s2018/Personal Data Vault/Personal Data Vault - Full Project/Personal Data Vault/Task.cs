﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;


namespace Personal_Data_Vault
{

    //used for task.what() to tell what type each task is.
    public enum taskType {NOT_INIT, DATA_REQUESTED_TASK, DATA_SHARED_TASK, BLOCK_ADDITION_REQUEST_TASK, BLOCK_ADDITION_RECEIVED_TASK};//so this shouldn't need to exist anymore


    //abstract class, all tasks are stored in an array of this type.
    [Serializable]
    public class Task
    {
        public int other_user { get; set; }
        public List<int> associatedBlocks { get; set; }
        public List<string> associatedData { get; set; } //filenames of associated data
        public string descriptor { get; set; } //message made by user who created the task
     
        internal Task(int other = 0, string message = "", List<int> blocks = null, List<string> data = null)
        {
            other_user = other;
            descriptor = message;
            //initialize the lists if nonexistent
            associatedBlocks = (blocks == null ? new List<int>() : blocks);
            associatedData = (data == null ? new List<string>() : data);
        }
        virtual internal taskType what() {
            return taskType.NOT_INIT;
        }

        //opens the respective task window
        virtual internal void initTask() {
            return;
        }
    }

    //another user sent a request for us to share some data in our PDV with them.
    //features a checklist for user to select by tag or individual file what to send.
    [Serializable]
    public class DataRequestedTask : Task
    {
        public DataRequestedTask() : base() { }
        public DataRequestedTask(int other, string message, List<int> blocks, List<string> data) : base(other, message, blocks, data) { }
        override internal taskType what() { return taskType.DATA_REQUESTED_TASK; }
        internal override void initTask(){
            DataRequestedTaskWindow tWin = new DataRequestedTaskWindow(Block.tasks.IndexOf(this));
            tWin.ShowDialog();
        }
    }

    //another user has shared data from their PDV with us.  
    //features list of all shared files - click on any file to download that file to location of user's choosing
    [Serializable]
    public class dataSharedTask : Task
    {
        public dataSharedTask() : base() { }
        public dataSharedTask(int other, string message, List<int> blocks, List<string> data) : base(other, message, blocks, data) { }
        internal override taskType what() { return taskType.DATA_SHARED_TASK; }
        internal override void initTask(){
            DataSharedTaskWindow window = new DataSharedTaskWindow(Block.tasks.IndexOf(this));
            window.ShowDialog();
        }

    }

    //Another user has asked that we send data for them to add to their PDV
    //user can upload files, then currently has a checklist of which uploaded files to send (should be a "remove" button but this is what I have for now)
    [Serializable]
    public class BlockAdditionRequestTask : Task
    {
        public BlockAdditionRequestTask() : base() { }
        public BlockAdditionRequestTask(int other, string message, List<int> blocks, List<string> data) : base(other, message, blocks, data) { }
        internal override taskType what() { return taskType.BLOCK_ADDITION_REQUEST_TASK; }
        internal override void initTask() {
            BlockAdditionRequestTaskWindow window = new BlockAdditionRequestTaskWindow(Block.tasks.IndexOf(this));
            window.ShowDialog();
        }
    }

    //another user has sent over files for us to add to our PDV
    //user can select via checkbox which files to actually add, then click finish to add them.
    [Serializable]
    public class BlockAdditionReceivedTask : Task
    {
        public BlockAdditionReceivedTask() : base() { }
        public BlockAdditionReceivedTask(int other, string message, List<int> blocks, List<string> data) : base(other, message, blocks, data) { }
        internal override taskType what() { return taskType.BLOCK_ADDITION_RECEIVED_TASK; }
        internal override void initTask() {
            BlockAdditionReceivedTaskWindow window = new BlockAdditionReceivedTaskWindow(Block.tasks.IndexOf(this));
            window.ShowDialog();
        }
    }

    //wrapper class for checkBoxes of tags
    public class TagCheckBox : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private bool isChecked;
        private string item;
        public TagCheckBox()
        { }
        public TagCheckBox(string item, bool isChecked = false)
        {
            this.item = item;
            this.isChecked = isChecked;
        }
        public string Item
        {
            get { return item; }
            set
            {
                item = value;
                if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("Item"));
            }
        }
        public bool IsChecked
        {
            get { return isChecked; }
            set
            {
                isChecked = value;
                if (PropertyChanged != null) {
                    PropertyChanged(this, new PropertyChangedEventArgs("IsChecked"));
                    //update all appropriate block checkboxes 
                }
            }
        }
    }

    //wrapper class for checkboxes of blocks
    public class BlockCheckBox : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private bool isChecked;
        private string item;
        public int index;
        public BlockCheckBox()
        { }
        public BlockCheckBox(string fileName, int index, bool isChecked = false)
        {
            this.item = fileName;
            this.index = index;
            this.isChecked = isChecked;
        }
        public string Item
        {
            get { return item; }
            set
            {
                item = value;
                if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("Item"));
            }
        }
        public bool IsChecked
        {
            get { return isChecked; }
            set
            {
                isChecked = value;
                if (PropertyChanged != null)
                {
                    PropertyChanged(this, new PropertyChangedEventArgs("IsChecked"));
                    
                }
            }
        }
    }

    //wrapper class for checkboxes of files
    public class FileCheckBox : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private bool isChecked;
        private string item;
        public int index;
        public FileCheckBox()
        { }
        public FileCheckBox(string fileName, int index, bool isChecked = false)
        {
            this.item = fileName;
            this.index = index;
            this.isChecked = isChecked;
        }
        public string Item
        {
            get { return item; }
            set
            {
                item = value;
                if (PropertyChanged != null) PropertyChanged(this, new PropertyChangedEventArgs("Item"));
            }
        }
        public bool IsChecked
        {
            get { return isChecked; }
            set
            {
                isChecked = value;
                if (PropertyChanged != null)
                {
                    PropertyChanged(this, new PropertyChangedEventArgs("IsChecked"));

                }
            }
        }
    }

    //wrapper class for buttons to open tasks
    public class taskButton {
        public int index { get; set; }
        Task associatedTask;
        public taskButton() { }
        public taskButton(int _index) {
            index = _index;
            associatedTask = Block.tasks[index];
        }
        public Task Item
        {
            get { return associatedTask; }
        }
    }

    //wrapper class for file buttons
    public class fileButton {
        public string fileName { get; set; }
        public fileButton() { }
        public fileButton(string name) {
            fileName = name;
        }
        public string Item {
            get { return fileName; }
        }
    }
}