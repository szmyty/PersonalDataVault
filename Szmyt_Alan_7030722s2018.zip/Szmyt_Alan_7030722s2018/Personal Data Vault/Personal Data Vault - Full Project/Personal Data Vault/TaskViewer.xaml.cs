﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Collections.ObjectModel;

namespace Personal_Data_Vault
{
    /// <summary>
    /// Interaction logic for TaskWindow.xaml
    /// </summary>
    ///
    [Serializable]
    public partial class TaskViewer : Window
    {

        public ObservableCollection<taskButton> taskButtons { get; set; }
        int taskIndex { get; set; }
        public Task taskInSession { get; set; }

        public TaskViewer()
        {
            int whatTask = 0;
            InitializeComponent();
            taskButtons = new ObservableCollection<taskButton>();
            for (int i = 0; i < Block.tasks.Count; i++) {
                taskButtons.Add(new Personal_Data_Vault.taskButton(i));
            }
            taskInSession = Block.tasks[whatTask];
            taskIndex = whatTask;
            DataContext = this;
        }

        private void openTaskClick(object sender, RoutedEventArgs e) {
            Button button = sender as Button;
            int index = (int)button.Tag;
            Block.tasks[index].initTask();
        }

        private void Finish(object sender, RoutedEventArgs e)
        {
            //finish the task and go send off dat data
            //send data to other user via associatedBlocks.
            Close();
        }
    }
}