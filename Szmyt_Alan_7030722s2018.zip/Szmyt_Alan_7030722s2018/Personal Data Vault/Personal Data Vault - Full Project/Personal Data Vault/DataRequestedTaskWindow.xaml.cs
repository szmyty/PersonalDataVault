﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Collections.ObjectModel;

namespace Personal_Data_Vault
{
    [Serializable]
    public partial class DataRequestedTaskWindow : Window
    {

        //select whole tags to share
        public ObservableCollection<TagCheckBox> checkTags { get; set; }
        //select individual blocks to share
        public ObservableCollection<BlockCheckBox> checkBlocks { get; set; }
        int taskIndex { get; set; }
        public Task taskInSession { get; set; }

        //when tag is checked need to check all blocks with that tag
        private void tagCheckBoxChecked(object sender, RoutedEventArgs e) {
            CheckBox obj = (CheckBox)sender;
            for (int i = 0; i < Block.tags.Count; i++) {
                if (Block.tags[i].Key == (string)obj.Content)
                    for (int j = 0; j < checkBlocks.Count(); j++)
                    {
                        if (checkBlocks[j].index == Block.tags[i].Value)
                            checkBlocks[j].IsChecked = true;
                    }
            }
        }

        //uncheck all blocks under this tag if tag is unchecked
        private void tagCheckBoxUnChecked(object sender, RoutedEventArgs e)
        {
            CheckBox obj = (CheckBox)sender;
            for (int i = 0; i < Block.tags.Count; i++)
            {
                if (Block.tags[i].Key == (string)obj.Content) {
                    for (int j = 0; j < checkBlocks.Count(); j++) {
                        if (checkBlocks[j].index == Block.tags[i].Value)
                            checkBlocks[j].IsChecked = false;
                    }
                }
                   // checkBlocks[Block.tags[i].Value].IsChecked = false;
            }
        }

        public DataRequestedTaskWindow(int whatTask)
        {
            InitializeComponent();

            checkTags = new ObservableCollection<TagCheckBox>();
            checkBlocks = new ObservableCollection<BlockCheckBox>();
            taskInSession = Block.tasks[whatTask];
            taskIndex = whatTask;
            
            //find all tags
            List<string> tagList = new List<string>();
            for (int i = 0; i < Block.tags.Count; i++)
            {
                if (!tagList.Contains(Block.tags[i].Key))
                    tagList.Add(Block.tags[i].Key);
            }

            foreach (string tag in tagList)
            {
                checkTags.Add(new TagCheckBox(tag));
            }

            for (int i = 0, count = 0; i < Block.blocks.Count; i++) {

                Console.WriteLine(Block.blocks[i].fullFileName);
                if (!Block.blocks[i].deleted)
                {
                    checkBlocks.Add(new BlockCheckBox(Block.blocks[i].fullFileName, i, taskInSession.associatedBlocks.Contains(count)));
                }
                else
                    count++;
            }
            DataContext = this;
        }

        private void Save_Task_Click(object sender, RoutedEventArgs e) {
            //save with all current checked boxes
            List<int> blocks = new List<int>();
            for (int i = 0; i < checkBlocks.Count; i++) {
                if (checkBlocks[i].IsChecked) {
                    blocks.Add(i);
                }
            }
            taskInSession.associatedBlocks = blocks;
            Block.tasks[taskIndex] = taskInSession;
            Block.Save();
            Close();
        }

        private void Finish_Task(object sender, RoutedEventArgs e) {
            //finish the task and go send off dat data
            //send data to other user via associatedBlocks.
            Close();
        }
    }
}