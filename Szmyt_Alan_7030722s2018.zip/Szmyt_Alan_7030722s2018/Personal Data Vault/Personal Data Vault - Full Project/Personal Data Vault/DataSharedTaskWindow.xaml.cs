﻿using System;
using System.IO;
using System.Windows;
using Microsoft.Win32;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace Personal_Data_Vault
{
    [Serializable]
    public partial class DataSharedTaskWindow : Window
    {
        public List<string> files { get; set; }
        //buttons to click to download respective files
        public ObservableCollection<fileButton> fileButtons { get; set; }
        int taskIndex;
        public Task taskInSession { get; set; }
        public DataSharedTaskWindow(int whatTask)
        {
            InitializeComponent();
            taskIndex = whatTask;
            taskInSession = Block.tasks[taskIndex];
            //sharedData is our current dummy folder which holds the data the other user shared with us.
            //so we go to that folder and grab all the files in it as options to download
            //in reality will have different folders each labeled with other user id or task id
            string path = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + "/Personal Data Vault/sharedData";
            files = new List<string>(Directory.GetFiles(path, "*", SearchOption.AllDirectories));
            fileButtons = new ObservableCollection<fileButton>();
            for (int i = 0; i < files.Count; i++) {
                fileButtons.Add(new fileButton(files[i]));
            }
            DataContext = this;
        }

        //allow user to select location to download file
        void download_click(object sender, RoutedEventArgs e)
        {
            Button pressed = sender as Button;
            string file = pressed.Content.ToString();
            SaveFileDialog dialog = new SaveFileDialog();
            if (dialog.ShowDialog() == true)
            {
                //so they selected a place to save it
                System.IO.File.Copy(file, dialog.FileName, true);
            }
        }

        private void Save_Task_Click(object sender, RoutedEventArgs e) {
            //nothing to save here really
            Close();
        }

        private void Finish_Task(object sender, RoutedEventArgs e) {
            //should delete the task, but for our purposes will leave for demo
            Close();
        }

    }
}
