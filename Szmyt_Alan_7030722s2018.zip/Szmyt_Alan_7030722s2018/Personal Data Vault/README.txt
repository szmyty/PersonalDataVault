Personal Data Vault Submission

BlockchainSimple: This code was written by Matt Pelland when we started. It is written in C++ and is a very basic blockchain structure that we used for our project. I converted it from C++ to C# and expanded upon it for use with the Personal Data Vault.

Personal Data Vault - Alan Szmyt Only: This project folder is all of the code that I wrote up myself (excluding the original blockchain structure that I expanded upon and the delete functionality, which was written by Matt).

Personal Data Vault - Full Project: This project folder is our entire project thus far. I added in the task system that Matt worked on to my own project files.

genKeys: This folder is Justin's work which is the cryptography portion of the project to get user accounts and public/private keys via OpenSSL. 

Personal Data Vault Final Report: This is my report on the project.

To Run this program, open the Personal Data Vault.exe file or goto Szmyt_Alan_7030722s2018\Personal Data Vault - Full Project\Personal Data Vault\obj\Debug and open up the Personal Data Vault.exe file.