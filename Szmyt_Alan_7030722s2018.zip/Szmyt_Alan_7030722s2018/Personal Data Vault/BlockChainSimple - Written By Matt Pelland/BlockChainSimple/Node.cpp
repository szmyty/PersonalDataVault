#include "Node.h"
#include "SHA256.h"
#include <ctime>


Node::Node(int id) {
	Node::id = id;
	personalChain = BlockChain();
	signature = sha256(std::to_string(id) + std::to_string(time(0))); //make this more complicated
}

Block Node::getLatestBlock() {
	return personalChain.getLatestBlock();
}

void Node::displayChain() {
	std::cout << personalChain;
}

bool Node::isChainValid(BlockChain checking) {
	for (int i = 1; i < checking.length(); i++) {
		Node creator = nodeList[checking.chain[i].creator_id];
		if (!checking.chain[i].isBlockValid(checking.chain[i-1]) || !creator.verifySignature(checking.chain[i]))
			return false;
	}
	return true;
}

bool Node::verifySignature(Block checking) {
	std::string blockSignature = sha256(std::to_string(checking.index + 1) + checking.getHash() + std::to_string(checking.data) + std::to_string(id) + signature);
	return checking.signature == blockSignature;
}

bool Node::requestPush(Node& other, int data) {
	Block latest = other.getLatestBlock();
	std::string blockSignature = sha256(std::to_string(latest.index + 1) + latest.getHash() + std::to_string(data) + std::to_string(id) + signature);
	Block toPush(latest.index + 1, latest.getHash(), data, id, blockSignature);
	return other.pushRequested(toPush);
}

bool Node::requestPush(Node& other, Block toPush) {
	return other.pushRequested(toPush);
}


//in app this would probbly also require the user to manually confirm to add
bool Node::pushRequested(Block toPush) {
	if (toPush.isBlockValid(getLatestBlock()) && verifySignature(toPush)) {
		personalChain.addBlock(toPush);
		return true;
	}
	return false;
}

Node::~Node()
{
}


std::ostream& operator<<(std::ostream& out, const Node& toShow) {
	out << "id: " << toShow.id << std::endl;
	return out << toShow.personalChain;
}