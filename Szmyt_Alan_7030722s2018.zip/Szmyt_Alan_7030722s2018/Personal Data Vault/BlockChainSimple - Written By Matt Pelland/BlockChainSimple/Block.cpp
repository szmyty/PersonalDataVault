#include "Block.h"


Block::Block(int index, std::string previousHash, int data, int creator, std::string signature)
{
	Block::index = index;
	Block::previousHash = previousHash;
	Block::timestamp = time(0);
	Block::data = data;
	Block::creator_id = creator;
	Block::signature = signature;
	Block::hash = calculateHashPOW();
}


Block::~Block()
{
}

std::ostream& operator<<(std::ostream& out, Block toPrint) {
	return out << "\tindex: " << toPrint.index << std::endl <<
		"\tcreator: " << toPrint.creator_id << std::endl <<
		"\tsignature: " << toPrint.signature << std::endl <<
		"\tpreviousHash: " << toPrint.previousHash << std::endl <<
		"\ttimestamp: " << toPrint.timestamp << std::endl <<
		"\tdata: " << toPrint.data << std::endl <<
		"\thash: " << toPrint.hash << std::endl;
}

std::string Block::getHash() { return hash; }


std::string Block::calculateHash() {
	return calculateHashPOW();
	/*std::string collect = std::to_string(index) + previousHash + std::to_string(timestamp) + std::to_string(data);
	return sha256(collect);*/
}

std::string Block::calculateHashPOW() {
	std::string collect = std::to_string(index) + previousHash + std::to_string(timestamp) + std::to_string(data) + std::to_string(creator_id) + signature;
	int nonce = 0;
	while (!acceptableHash(sha256(collect + std::to_string(nonce)))) {
		nonce++;
	}
	return sha256(collect + std::to_string(nonce));
}

//numZeroes defines how difficult the POW is
bool Block::acceptableHash(std::string hash) {
	int numZeroes = 4;
	for (int i = 0; i < numZeroes; i++) {
		if (hash[i] != '0')
			return false;
	}
	return true;
}

bool Block::isBlockValid(Block previousBlock) {
	std::string aHash = calculateHash();
	if (hash != aHash) {
		std::cout << "Block index " << index << " has hash " << hash << " but it should have hash " << aHash << std::endl;
		return false;
	}
	if (index != previousBlock.index + 1) {
		std::cout << "Block index " << index << " references as previous block a block of index " << previousBlock.index << std::endl;
		return false;
	}
	if (previousBlock.hash != previousHash) {
		std::cout << "prev hash field in block " << index << " does not match hash in block " << index - 1 << std::endl;
		return false;
	}
	return true;
}