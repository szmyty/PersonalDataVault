#include "BlockChain.h"

//todo:
//implement proof of work DONE
//output blockchain as xml
//implement rollback if chain is invalid DONE
//prevent personal attacks
//need a way to ensure that user can't make blocks put on by others appear to be put on by him.  How to do that...

BlockChain::BlockChain()
{
	chain = std::vector<Block>();
	chain.push_back(createGenesisBlock());
}

BlockChain::~BlockChain()
{
}

Block BlockChain::createGenesisBlock() {
	return Block(0, "", 0, 0, "");
}

void BlockChain::addBlock(Block toAdd) {
	if(toAdd.isBlockValid(chain.at(chain.size()-1)))
		chain.push_back(toAdd);
}

void BlockChain::addBlock(int data, int creator, std::string signature) {
	chain.push_back(Block(chain.size(), chain.at(chain.size()-1).getHash(), data, creator, signature));
}

int BlockChain::length() {
	return chain.size();
}

Block BlockChain::getLatestBlock() {
	return chain.at(chain.size() - 1);
}

//currently this doesn't itself call rollBack, so the user has to call rollBack themselves
bool BlockChain::isChainValid() {
	for (int i = 1; i < chain.size(); i++) {
		if (!(chain.at(i).isBlockValid(chain.at(i - 1))))
			return false;
	}
	lastValidChain = chain;
	return true;
}

bool BlockChain::replaceChain(BlockChain other) {
	if (other.isChainValid() && other.length() > length()) {
		*this = other;
	}
	return true;
}

void BlockChain::rollBackChain() {
	if (!isChainValid()) {
		chain = lastValidChain;
	}
}

std::ostream& operator<< (std::ostream& out, BlockChain toPrint) {
	out << "size: " << toPrint.chain.size() << std::endl;
	for (int i = 0; i < toPrint.chain.size(); i++) {
		out << toPrint.chain.at(i)<<std::endl;
	}
	return out;
}