#pragma once
#include "BlockChain.h"
#include <string>
#include<iostream>
class Node
{
public:
	Node(int id);
	~Node();
	//send request to another node to puhs a block to their blockchain
	bool requestPush(Node& other, int data);
	bool requestPush(Node& other, Block toPush);
	//another node has requested to push to your blockchain
	bool pushRequested(Block toPush);
	Block getLatestBlock();
	void displayChain();
	friend std::ostream& operator<<(std::ostream& out, const Node& toShow);
	bool isChainValid(BlockChain checking);
	bool verifySignature(Block checking);
private:
	std::vector<Node> nodeList;
	int id;
	BlockChain personalChain;
	std::string signature;
};

