#include"BlockChain.h"
#include<iostream>
#include "Node.h"
#include<vector>

void addNode(std::vector<Node>&);
void addNode(std::vector<Node>&, const Node& toAdd);


int main(int argc, char* argv[]) {
	std::vector<Node> nodes;
	addNode(nodes);
	addNode(nodes);
	nodes[1].requestPush(nodes[0], 7);
	std::cout << nodes[0];
}

void addNode(std::vector<Node>& nodeList) {
	nodeList.push_back(Node(nodeList.size()));
}

void addNode(std::vector<Node>& nodeList, const Node& toAdd) {
	nodeList.push_back(toAdd);
}