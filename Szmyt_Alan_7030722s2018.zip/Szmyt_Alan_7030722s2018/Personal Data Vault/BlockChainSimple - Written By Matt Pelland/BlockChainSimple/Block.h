#pragma once
#include <ctime>
#include <string>
#include <iostream>
#include "SHA256.h"
class Block
{

public:

	Block(int index, std::string previousHash, int data, int creator, std::string signature);
	bool isBlockValid(Block previousBlock);
	std::string getHash();
	~Block();
	friend std::ostream& operator<<(std::ostream& out, Block toPrint);
	int creator_id;
//private:
	std::string signature;
	int index;
	std::string previousHash;
	time_t timestamp;
	int data; //changes depending on the type of data
	std::string hash;
	std::string calculateHash();
	std::string calculateHashPOW();
	bool acceptableHash(std::string hash);
};

