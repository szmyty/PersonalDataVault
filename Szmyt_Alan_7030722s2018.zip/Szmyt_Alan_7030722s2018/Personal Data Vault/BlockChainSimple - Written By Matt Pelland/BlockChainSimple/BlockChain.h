#pragma once
#include<vector>
#include<iostream>
#include"Block.h"
class BlockChain
{
public:
	BlockChain();
	~BlockChain();
	void addBlock(Block toAdd);
	void addBlock(int data, int creator, std::string signature);
	bool isChainValid();
	bool replaceChain(BlockChain other);
	friend std::ostream& operator<<(std::ostream& out, BlockChain toOutput);
	int length();
	Block getLatestBlock();
//private:
	std::vector<Block> lastValidChain;
	void rollBackChain();
	std::vector<Block> chain;
	Block createGenesisBlock();

};